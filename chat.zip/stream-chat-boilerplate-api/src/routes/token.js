import { token } from "../controllers/v1/token";
import { StreamChat } from 'stream-chat';
import { wrapAsync } from "../utils/controllers";

module.exports = api => {
  api.route("/hook").post(async function(req, res) {

  	const client = new StreamChat(process.env.STREAM_API_KEY, process.env.STREAM_API_SECRET);

  	const data = {"id":"john","name":"john doe"}

  	const conversation = client.channel(
      "commerce",
      "conversational-ui"
    );

    const channelResponse = await conversation.create();

	const text = 'I was gonna get to mars but then I got high';
	const message = {
	    text
	}

	const response = await conversation.sendMessage(message);

  	res.send("test");
  });

  api.route("/v1/token").post(wrapAsync(token));
};
