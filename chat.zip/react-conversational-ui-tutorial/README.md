This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

This project accompanies a [tutorial]() on building a conversational UI in React using Stream Chat API and KendoReact COnversational UI components.

## Set Ups

1. Clone and set up the [token server](https://github.com/pmbanugo/stream-chat-boilerplate-api) by following the instruction on that repo.

2. Clone this repo and run `npm install`.
3. Run `npm start` to start the React app.
